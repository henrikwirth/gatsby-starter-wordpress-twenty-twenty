# GraphiQL IDE

[GraphiQL IDE](https://github.com/graphql/graphiql) is a web based IDE interface for interacting with GraphQL APIs.

This implementation is tailored to work specifically with WPGraphQL. 
