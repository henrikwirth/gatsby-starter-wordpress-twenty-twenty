<?php
namespace FakerPress\Fields;

class Raw extends Field_Abstract {
	/**
	 * {@inheritDoc}
	 */
	protected $slug = 'raw';
}